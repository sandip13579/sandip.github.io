import { Mail, Phone, MapPin } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-primary text-white mt-16">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          <div>
            <h3 className="text-lg font-bold mb-4 flex items-center space-x-2">
              <span>⚖️</span>
              <span>Court Attendance & Witness Tracking</span>
            </h3>
            <p className="text-white/80">
              Ensuring timely attendance of Investigating Officers and witnesses to improve conviction rates and minimize adjournments.
            </p>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-white/80">
              <li><a href="#" className="hover:text-white transition-colors">Daily Cause List</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Attendance Tracking</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Performance Dashboard</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Notifications</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-4">Contact Information</h4>
            <ul className="space-y-3 text-white/80">
              <li className="flex items-center space-x-2">
                <Phone size={18} />
                <span>+91-674-2359000</span>
              </li>
              <li className="flex items-center space-x-2">
                <Mail size={18} />
                <span>info@odishapolice.gov.in</span>
              </li>
              <li className="flex items-start space-x-2">
                <MapPin size={18} className="mt-1" />
                <span>Odisha Police Headquarters, Bhubaneswar</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/20 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center text-white/70 text-sm">
            <p>&copy; 2024 Odisha Police. All rights reserved.</p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
              <a href="#" className="hover:text-white transition-colors">Accessibility</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
