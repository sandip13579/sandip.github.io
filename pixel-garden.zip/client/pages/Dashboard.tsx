import { BarChart3 } from "lucide-react";

export function Dashboard() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-16">
        <div className="text-center py-16">
          <BarChart3 size={64} className="mx-auto text-primary/30 mb-4" />
          <h1 className="text-3xl font-bold text-primary mb-2">Performance Dashboard</h1>
          <p className="text-gray-600 text-lg mb-8">
            Analytics and performance metrics for officers and court cases
          </p>
          <div className="bg-white rounded-2xl shadow-md p-8 max-w-2xl mx-auto">
            <p className="text-gray-700 mb-4">
              This page will showcase comprehensive performance analytics with:
            </p>
            <ul className="text-left space-y-2 text-gray-700 mb-6">
              <li>✓ Officer-wise attendance percentage</li>
              <li>✓ Conviction rate trends (Recharts integration)</li>
              <li>✓ Monthly compliance reports</li>
              <li>✓ Table and graph comparisons</li>
              <li>✓ Export functionality (CSV/PDF)</li>
            </ul>
            <p className="text-sm text-gray-500">
              More details coming soon. Continue building this feature!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
