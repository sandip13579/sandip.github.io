import { Bell } from "lucide-react";

export function Notifications() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-16">
        <div className="text-center py-16">
          <Bell size={64} className="mx-auto text-primary/30 mb-4" />
          <h1 className="text-3xl font-bold text-primary mb-2">Notifications & Alerts</h1>
          <p className="text-gray-600 text-lg mb-8">
            Upcoming hearings, reminders, and automated alerts
          </p>
          <div className="bg-white rounded-2xl shadow-md p-8 max-w-2xl mx-auto">
            <p className="text-gray-700 mb-4">
              This page will display comprehensive notifications and alerts including:
            </p>
            <ul className="text-left space-y-2 text-gray-700 mb-6">
              <li>✓ Upcoming hearings and reminders</li>
              <li>✓ Automated alerts (24 hours before cases)</li>
              <li>✓ Missed attendance notifications</li>
              <li>✓ Escalation alerts to SDPO/SP</li>
              <li>✓ Manual SMS/App notification sending</li>
            </ul>
            <p className="text-sm text-gray-500">
              More details coming soon. Continue building this feature!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
