import { FileText } from "lucide-react";

export function CauseList() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-16">
        <div className="text-center py-16">
          <FileText size={64} className="mx-auto text-primary/30 mb-4" />
          <h1 className="text-3xl font-bold text-primary mb-2">Daily Cause List</h1>
          <p className="text-gray-600 text-lg mb-8">
            View and manage daily court cause lists, filter by court and date
          </p>
          <div className="bg-white rounded-2xl shadow-md p-8 max-w-2xl mx-auto">
            <p className="text-gray-700 mb-4">
              This page will display a comprehensive table with case information, hearing details, and attendance requirements. Features include:
            </p>
            <ul className="text-left space-y-2 text-gray-700 mb-6">
              <li>✓ Case Number, Court Name, and Hearing Date & Time</li>
              <li>✓ Required Attendance (IO/Witness)</li>
              <li>✓ Status tracking (Pending/Completed)</li>
              <li>✓ Advanced filters by court, date, and officer</li>
              <li>✓ Import functionality with animation</li>
            </ul>
            <p className="text-sm text-gray-500">
              More details coming soon. Continue building this feature!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
