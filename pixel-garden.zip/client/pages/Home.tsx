import { Link } from "react-router-dom";
import { StatCard } from "../components/StatCard";
import { ArrowRight, FileText, Users, Bell, BarChart3 } from "lucide-react";

export function Home() {
  const stats = [
    { icon: "📋", label: "Total Cases Today", value: "47", trend: "+12%" },
    { icon: "👮", label: "IOs Present", value: "38", trend: "+8%", trendUp: true },
    { icon: "👥", label: "Witnesses Present", value: "156", trend: "-3%", trendUp: false },
    { icon: "📈", label: "Conviction Rate", value: "82%", trend: "+5%", trendUp: true },
  ];

  const quickLinks = [
    {
      icon: FileText,
      name: "Daily Cause List",
      description: "View and manage daily court cause lists",
      path: "/cause-list",
      color: "from-blue-50 to-blue-100",
      iconColor: "text-blue-600",
    },
    {
      icon: Users,
      name: "IO Attendance",
      description: "Mark and track officer attendance",
      path: "/attendance",
      color: "from-purple-50 to-purple-100",
      iconColor: "text-purple-600",
    },
    {
      icon: Bell,
      name: "Notifications",
      description: "View alerts and reminders",
      path: "/notifications",
      color: "from-amber-50 to-amber-100",
      iconColor: "text-amber-600",
    },
    {
      icon: BarChart3,
      name: "Performance Dashboard",
      description: "View performance metrics and trends",
      path: "/dashboard",
      color: "from-green-50 to-green-100",
      iconColor: "text-green-600",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary via-primary to-primary/90 text-white py-16 px-4">
        <div className="container mx-auto">
          <div className="max-w-3xl">
            <div className="flex items-center space-x-4 mb-6">
              <div className="w-16 h-16 bg-white rounded-xl flex items-center justify-center text-3xl">
                ⚖️
              </div>
              <div>
                <h1 className="text-4xl md:text-5xl font-bold mb-2">
                  Court Attendance & Witness Tracking System
                </h1>
                <p className="text-lg text-white/90">Odisha Police Department</p>
              </div>
            </div>
            <p className="text-xl text-white/95 leading-relaxed mb-8">
              Ensuring timely attendance of Investigating Officers and witnesses to improve conviction rates and minimize adjournments.
            </p>
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-primary mb-4">Real-time Metrics</h2>
          <p className="text-gray-600 mb-8">Today's performance overview</p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {stats.map((stat, index) => (
              <StatCard
                key={index}
                icon={stat.icon}
                label={stat.label}
                value={stat.value}
                trend={stat.trend}
                trendUp={stat.trendUp !== false}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Quick Links Section */}
      <section className="bg-gray-50 py-16 px-4">
        <div className="container mx-auto">
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-primary mb-4">Main Features</h2>
            <p className="text-gray-600">Access key features and functionalities</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {quickLinks.map((link) => {
              const Icon = link.icon;
              return (
                <Link
                  key={link.path}
                  to={link.path}
                  className="group"
                >
                  <div className={`bg-gradient-to-br ${link.color} rounded-2xl p-8 h-full transition-all duration-300 hover:shadow-lg hover:scale-105`}>
                    <div className={`${link.iconColor} mb-4 transition-transform group-hover:scale-110`}>
                      <Icon size={40} />
                    </div>
                    <h3 className="text-xl font-bold text-primary mb-2">
                      {link.name}
                    </h3>
                    <p className="text-gray-700 text-sm mb-4">
                      {link.description}
                    </p>
                    <div className="flex items-center text-primary font-semibold text-sm group-hover:translate-x-1 transition-transform">
                      Access <ArrowRight size={16} className="ml-2" />
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-primary text-white py-16 px-4">
        <div className="container mx-auto text-center max-w-2xl">
          <h2 className="text-3xl font-bold mb-4">Get Started Today</h2>
          <p className="text-lg text-white/90 mb-8">
            Start tracking attendance and managing court cases efficiently with our comprehensive system.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/attendance"
              className="bg-white text-primary px-8 py-3 rounded-lg font-bold hover:bg-white/90 transition-colors"
            >
              Mark Attendance
            </Link>
            <Link
              to="/cause-list"
              className="border-2 border-white text-white px-8 py-3 rounded-lg font-bold hover:bg-white/10 transition-colors"
            >
              View Cause List
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
